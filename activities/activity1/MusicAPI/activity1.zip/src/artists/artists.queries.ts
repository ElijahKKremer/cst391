export const artistQueries = {
    readArtists:
        `select distinct artist as artist from music.albums`
}
